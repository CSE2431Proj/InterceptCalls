# InterceptCalls

DO NOT USE THE CURRENT PROJECT DEMO VERSION WITHOUT BACKING UP FIRST>>> KERNEL MODULE IS UNREMOVABLE!!!!!

For full uninstall capability, comment out line 166 of "\lkm\infection.c"
